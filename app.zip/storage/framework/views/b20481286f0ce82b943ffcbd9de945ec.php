<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <meta charset="utf-8">
    <?php $__env->startSection('title','Laporan Keuangan | Batik Kiki Sales'); ?>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <h4 class="font-semibold text-gray-800 leading-tight">
            <?php echo e(__('Laporan Keuangan')); ?>

        </h4>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                <div class="row justify-content-between">
                    <div class="col-3">
                    <?php if(Route::is('laporanKeuangan')): ?>
                     <a href="/laporan/cetakpdf" class="btn btn-outline-primary mb-4">Cetak Pdf</a>
                    <?php else: ?>    
                        <a href="/laporan/cetakpdffilter?start_date=<?php echo e(app('request')->input('start_date')); ?>&end_date=<?php echo e(app('request')->input('end_date')); ?>" class="btn btn-outline-primary mb-4">Cetak PDF</a>
                    <?php endif; ?>
                    </div>
                    <div class="col-6">
                    <form action="<?php echo e(route('filterLaporan')); ?>" method="GET">
                        <small class="font-semibold text-gray-800 leading-tight">Filter tanggal laporan keuangan : </small>
                        <div class="input-group mt-1 mb-4">
                            <small class="font-semibold text-gray-800 mt-2 mr-2 leading-tight">Dari :  </small>
                            <input type="date" class="form-control" placeholder="Dari" name="start_date" required>
                            <small class="font-semibold text-gray-800 mt-2 ml-2 mr-2 leading-tight">Sampai : </small>
                            <input type="date" class="form-control" placeholder="Sampai" name="end_date" value="<?php echo e($now); ?>">
                            <button class="btn btn-outline-secondary" type="submit">Cari</button>
                            <a class="btn btn-outline-danger" href="/laporan">Reset filter</a>
                        </div>
                        </form>
                    </div>
                </div>
                
                <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                                <thead class="border-success">
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Deskripsi</th>
                                        <th>Pemasukkan</th>
                                        <th>Pengeluaran</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $tmasuk = 0;
                                $tkeluar = 0;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php
                                    $tmasuk += $dt->pemasukan;
                                $tkeluar += $dt->pengeluaran;
                                ?>
                                <?php if($loop->last): ?>
                                        <tr class=" border-black border-top border-start border-end">
                                    <?php else: ?>
                                    <tr>
                                    <?php endif; ?>
                                        <th class="border-end border-black"><?php echo e(++$key); ?></th>
                                        <th><?php echo e(date(" d F Y",strtotime($dt->date))); ?></th>
                                        <th><?php echo e($dt->type); ?></th>
                                        <th>Rp<?php echo e(number_format($dt->pemasukan,0,'','.')); ?></th>
                                        <th class="border-start border-black">Rp<?php echo e(number_format($dt->pengeluaran,0,'','.')); ?></th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class=" border-black">
                                       
                                        <td colspan="3" class="font-semibold">Jumlah</td>
                                        <td colspan="1"class="font-semibold">Rp<?php echo e(number_format($tmasuk,0,'','.')); ?></td>
                                        <td colspan="1"class="font-semibold">Rp<?php echo e(number_format($tkeluar,0,'','.')); ?></td>
                                    </tr>
                                    <?php
                                $pendapatan = 0;
                                $pendapatan = ($tmasuk-$tkeluar);
                                ?>
                                    <tr class=" border-black">
                                        <td colspan="3" class="font-semibold">Pendapatan</td>
                                        <td colspan="2"class="font-semibold">Rp<?php echo e(number_format($pendapatan,0,'','.')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            <?php echo $data->withQueryString()->links('pagination::bootstrap-5'); ?>

                            </div>
                            <!-- Option 1: Bootstrap Bundle with Popper -->
                        </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH D:\Kuliah\Skripsi\BatikKiki-Warehouse\resources\views/report/home.blade.php ENDPATH**/ ?>