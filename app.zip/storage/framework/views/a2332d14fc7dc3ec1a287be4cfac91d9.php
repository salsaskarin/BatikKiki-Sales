<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php $__env->startSection('title','Produk | Batik Kiki Sales'); ?>       
     <?php $__env->endSlot(); ?>
    

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <h4 class="font-semibold text-gray-800 leading-tight">
            <?php echo e(__('Daftar Produk')); ?>

        </h4> 
        <?php if(session()->has('msg')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('msg')); ?>

        </div>
        <?php endif; ?>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div> 
        <?php endif; ?>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                <div class="row justify-content-between">
                    <div class="col-3">
                    <a href="/produk/tambahProduk" class="btn btn-outline-primary">Tambah Produk</a>
                    </div>
                    <div class="col-3">
                    <form class="form" method="get" action="<?php echo e(route('search')); ?>">
                        <div class="form-group w-100 mb-3">
                            <input type="text" name="search" class="form-control w-75 d-inline" id="search" placeholder="Nama Produk">
                            <button type="submit" class="btn btn-outline-secondary mb-1">Cari</button>
                        </div>
                    </form>
                    </div>
                </div>
                

                <div class="row">
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-sm-12 mt-4 d-flex align-items-stretch">
                    <div class="card shadow sm:rounded-lg" style="width: 18rem;">
                        
                        <div class="card-body d-flex align-items-center">
                            <img src="/images/product/<?php echo e($product->image); ?>" class="card-img-top" alt="gambar">
                        </div>
                        <div class="card-footer text-sm">
                        <h5 class="card-title"><?php echo e($product->name); ?></h5>
                        <p class="card-text">Ukuran : <?php echo e($product->size); ?></p>
                        <p class="card-text">Harga Tertinggi : Rp<?php echo e(number_format($product->highest_price,0,'','.')); ?></p>
                        <p class="card-text">Harga Terendah : Rp<?php echo e(number_format($product->lowest_price,0,'','.')); ?></p>
                        <p class="card-text">Stok : <?php echo e($product->stock); ?></p>
                        <div class="form-group text-center">
                        <a href="/produk/detailProduk/<?php echo e($product->id); ?>" class="btn btn-info btn-sm">Detail</a>
                        <a href="/produk/editProduk/<?php echo e($product->id); ?>" class="btn btn-success btn-sm">Edit</a>
                        <a href="/produk/hapusProduk/<?php echo e($product->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin akan menghapus data ?');">Delete</a>
                        </div>
                        </div>
                    </div>       
                    </div>         
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
                 </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\Kuliah\Skripsi\BatikKiki-Warehouse\resources\views/product/home.blade.php ENDPATH**/ ?>