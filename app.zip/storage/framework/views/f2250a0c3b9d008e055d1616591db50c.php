<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <?php $__env->startSection('title','Produk | Batik Kiki Sales'); ?>  
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <h4 class="font-semibold text-gray-800 leading-tight">
            <?php echo e(__('Detail Produk')); ?>

        </h4>
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="text-end">
            <a href="/produk/editProduk/<?php echo e($product->id); ?>" class="btn btn-outline-success">Edit Produk</a>
            </div>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">

                <div class="p-6 text-gray-900 container">
                <div class="row">
                    <div class="col-4">
                    <img src="/images/product/<?php echo e($product->image); ?>">
                    </div>
                    <div class="col-8">
                    <h4 class="font-semibold text-gray-800 leading-tight mb-4"><?php echo e($product->name); ?></h4>
                    <h5 class="font-semibold text-gray-800 leading-tight mt-4">Ukuran :</h5>
                    <h6 class="text-gray-800 leading-tight mt-1"><?php echo e($product->size); ?></h6>
                    <h5 class="font-semibold text-gray-800 leading-tight mt-4">Jumlah Produk :</h6>
                    <h6 class="text-gray-800 leading-tight mt-1"><?php echo e($product->stock); ?></h6>
                    <h5 class="font-semibold text-gray-800 leading-tight mt-4">Harga Tertinggi :</h5>
                    <h6 class="text-gray-800 leading-tight mt-1">Rp<?php echo e(number_format($product->highest_price,0,'','.')); ?></h6>
                    <h5 class="font-semibold text-gray-800 leading-tight mt-4">Harga Terendah :</h5>
                    <h6 class="text-gray-800 leading-tight mt-1">Rp<?php echo e(number_format($product->lowest_price,0,'','.')); ?></h6>
                    <h5 class="font-semibold text-gray-800 leading-tight mt-4">Deskripsi Produk :</h5>
                    <h6 class="text-gray-800 leading-tight mt-1"><?php echo nl2br(e($product->details)); ?></h6>
                    </div>
                </div>
                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kuliah\Skripsi\BatikKiki-Warehouse\resources\views/product/detailsProduct.blade.php ENDPATH**/ ?>