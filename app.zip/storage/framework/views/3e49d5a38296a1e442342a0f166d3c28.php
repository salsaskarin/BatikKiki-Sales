<!DOCTYPE html>
<html>
<head>
	<title>Laporan Keuangan Toko Batik Kiki</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h4>Laporan Keuangan</h4>
		<h5>Toko Batik Kiki Cirebon</h5>
        <?php if(Route::is('cetakPdfFiltered')): ?>
        <h6>Tanggal <?php echo e(date('d M Y',strtotime($start_date))); ?> - <?php echo e(date('d M Y',strtotime($end_date))); ?></h6>
        <?php endif; ?>
	</center>
 
	<table class='table table-bordered'>
                                <thead class="border-success">
                                    <tr>
                                        <th>No</th>
                                        <th>Tanggal</th>
                                        <th>Deskripsi</th>
                                        <th>Pemasukkan</th>
                                        <th>Pengeluaran</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $tmasuk = 0;
                                $tkeluar = 0;
                                ?>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php
                                    $tmasuk += $data->pemasukan;
                                $tkeluar += $data->pengeluaran;
                                ?>
                                <?php if($loop->last): ?>
                                        <tr class=" border-black border-top border-start border-end">
                                    <?php else: ?>
                                    <tr>
                                    <?php endif; ?>
                                        <th class="border-end border-black"><?php echo e(++$key); ?></th>
                                        <th><?php echo e($data->date); ?></th>
                                        <th><?php echo e($data->type); ?></th>
                                        <th>Rp<?php echo e(number_format($data->pemasukan,0,'','.')); ?></th>
                                        <th class="border-start border-black">Rp<?php echo e(number_format($data->pengeluaran,0,'','.')); ?></th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class=" border-black">
                                       
                                        <td colspan="3" class="font-semibold">Jumlah</td>
                                        <td colspan="1"class="font-semibold">Rp<?php echo e(number_format($tmasuk,0,'','.')); ?></td>
                                        <td colspan="1"class="font-semibold">Rp<?php echo e(number_format($tkeluar,0,'','.')); ?></td>
                                    </tr>
                                    <?php
                                $pendapatan = 0;
                                $pendapatan = ($tmasuk-$tkeluar);
                                ?>
                                    <tr class=" border-black">
                                        <td colspan="3" class="font-semibold">Pendapatan</td>
                                        <td colspan="2"class="font-semibold">Rp<?php echo e(number_format($pendapatan,0,'','.')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            </div>
</body>
</html>

                <?php /**PATH D:\Kuliah\Skripsi\BatikKiki-Warehouse\resources\views/report/cetak.blade.php ENDPATH**/ ?>