<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <?php $__env->startSection('title','Pegawai | Batik Kiki Sales'); ?>
        
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <h4 class="font-semibold text-gray-800 leading-tight">
            <?php echo e(__('Daftar Pegawai')); ?>

        </h4>
        <?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('success')); ?>

        </div> 
        <?php endif; ?>
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                <div class="row justify-content-between">
                    <div class="col-3">
                    <a href="/user/tambahUser" class="btn btn-outline-primary mb-4">Tambah Pegawai</a>
                    </div>
                    <div class="col-3">
                    <form class="form" method="get" action="<?php echo e(route('searchUser')); ?>">
                        <div class="form-group w-100 mb-3">
                            <input type="text" name="search" class="form-control w-75 d-inline" id="search" placeholder="Nama Pegawai">
                            <button type="submit" class="btn btn-outline-secondary mb-1">Cari</button>
                            <a class="btn btn-outline-danger" href="/user">Reset filter</a>
                        </div>
                    </form>
                    </div>
                </div>
                
                <div class="table-responsive">
                <table class="table table-bordered table-hover text-center">
                                <thead class="border-success">
                                    <tr>
                                        <th>No</th>
                                        <th>Nama</th>
                                        <th>L/P</th>
                                        <th>Email</th>
                                        <th>Nomor Telepon</th>
                                        <th>Alamat</th>
                                        <th>Role</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($loop->index+1); ?></th>
                                        <th><?php echo e($user->name); ?></th>
                                        <th><?php echo e($user->gender); ?></th>
                                        <th><?php echo e($user->email); ?></th>
                                        <th><?php echo e($user->phone); ?></th>
                                        <th><?php echo e($user->address); ?></th>
                                        <?php if($user->is_Admin == 1 ): ?>
                                        <th>Admin</th>
                                        <?php else: ?>
                                        <th>Pegawai</th>
                                        <?php endif; ?>
                                    <th class="col-md-3">
                                        <div class="row justify-content-center">
                                        <div class="col-2">
                                                <a href="/user/editUser/<?php echo e($user->id); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            </div>
                                            <div class="col-6">
                                                <form action="/user/makeAdmin/<?php echo e($user->id); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <!-- <input type="hidden" name="id" value=""> -->
                                                    <input type="hidden" name="isAdmin" value=1>
                                                    <button type="submit" class="btn btn-success btn-sm">Jadikan admin</button>
                                                </form>
                                                
                                            </div>
                                        </div>
                                        <div class="row justify-content-center mt-1">
                                            <div class="col-2">
                                                <a href="/user/hapusUser/<?php echo e($user->id); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin akan menghapus data pegawai ini?');">Delete</a>
                                            </div>                                        
                                            <div class="col-6">
                                                <form action="user/makeAdmin/<?php echo e($user->id); ?>" method="POST">
                                                    <?php echo e(csrf_field()); ?>

                                                    <!-- <input type="hidden" name="id" value=""> -->
                                                    <input type="hidden" name="isAdmin" value=0>
                                                    <button type="submit" class="btn btn-info btn-sm">Hapus admin</button>
                                                </form>
                                            </div>
                                        </div>
                                    </th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Kuliah\Skripsi\BatikKiki-Warehouse\resources\views/user/home.blade.php ENDPATH**/ ?>